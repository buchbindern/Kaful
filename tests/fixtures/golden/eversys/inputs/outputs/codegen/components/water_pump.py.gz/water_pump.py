from progpy import PrognosticsModel
import numpy as np

class WaterPump(PrognosticsModel):
    """
    Critical hydraulic component supplying pressurized water to both boilers in the coffee machine
    """
    
    inputs = []
    
    outputs = [
        'water_supply'
    ]
    
    states = [
        'pump_efficiency',
        'water_flow_left', 
        'water_flow_right'
    ]
    
    events = [
        'water_flow_left_too_low',
        'water_flow_right_too_low'
    ]
    
    units = {
        'water_supply': 'bar',
        'pump_efficiency': 'percent',
        'water_flow_left': 'bar',
        'water_flow_right': 'bar'
    }
    
    default_parameters = {
        'pump_degradation_timescale': 500000.0,
        'pump_usage_factor': 1.0,
        'nominal_pressure': 3.25,
        'flow_tracking_coefficient': 0.3,
        'flow_split_ratio': 0.5,
        'low_flow_threshold': 0.5,
        'x0': {
            'pump_efficiency': 100.0,
            'water_flow_left': 3.25,
            'water_flow_right': 3.25
        }
    }
    
    def initialize(self, u=None, z=None):
        x = self.StateContainer({
            'pump_efficiency': 100.0,
            'water_flow_left': 1.625,   # nominal_pressure * flow_split_ratio
            'water_flow_right': 1.625,  # nominal_pressure * (1 - flow_split_ratio)
        })
        return x
    
    def next_state(self, x, u, dt):
        params = self.parameters
        
        # DEGRADATION state: pump_efficiency
        degradation_rate = 1.0 / params['pump_degradation_timescale']
        new_pump_efficiency = x['pump_efficiency'] - degradation_rate * params['pump_usage_factor'] * dt
        new_pump_efficiency = max(0.0, min(100.0, new_pump_efficiency))
        
        # Calculate current water supply for tracking targets
        water_supply = params['nominal_pressure'] * (new_pump_efficiency / 100.0)
        
        # TRACKING state: water_flow_left
        coefficient = min(params['flow_tracking_coefficient'], 0.5)
        target_left = water_supply * params['flow_split_ratio']
        new_water_flow_left = x['water_flow_left'] + coefficient * (target_left - x['water_flow_left']) * dt
        new_water_flow_left = max(0.0, min(5.0, new_water_flow_left))
        
        # TRACKING state: water_flow_right  
        target_right = water_supply * (1.0 - params['flow_split_ratio'])
        new_water_flow_right = x['water_flow_right'] + coefficient * (target_right - x['water_flow_right']) * dt
        new_water_flow_right = max(0.0, min(5.0, new_water_flow_right))
        
        return self.StateContainer({
            'pump_efficiency': new_pump_efficiency,
            'water_flow_left': new_water_flow_left,
            'water_flow_right': new_water_flow_right
        })
    
    def output(self, x):
        params = self.parameters
        water_supply = params['nominal_pressure'] * (x['pump_efficiency'] / 100.0)
        
        return self.OutputContainer({
            'water_supply': water_supply
        })
    
    def event_state(self, x):
        params = self.parameters
        
        # water_flow_left_too_low: 1.0 when healthy, 0.0 when occurred
        left_event_state = max(0.0, min(1.0, (x['water_flow_left'] - params['low_flow_threshold']) / params['low_flow_threshold']))
        right_event_state = max(0.0, min(1.0, (x['water_flow_right'] - params['low_flow_threshold']) / params['low_flow_threshold']))
        #left_event_state = max(0.0, min(1.0, (x['water_flow_left'] - params['low_flow_threshold']) / (5.0 - params['low_flow_threshold'])))
        
        # water_flow_right_too_low: 1.0 when healthy, 0.0 when occurred  
        #right_event_state = max(0.0, min(1.0, (x['water_flow_right'] - params['low_flow_threshold']) / (5.0 - params['low_flow_threshold'])))
        
        return {
            'water_flow_left_too_low': left_event_state,
            'water_flow_right_too_low': right_event_state
        }
    
    def threshold_met(self, x):
        params = self.parameters
        
        return {
            'water_flow_left_too_low': bool(x['water_flow_left'] < params['low_flow_threshold']),
            'water_flow_right_too_low': bool(x['water_flow_right'] < params['low_flow_threshold'])
        }