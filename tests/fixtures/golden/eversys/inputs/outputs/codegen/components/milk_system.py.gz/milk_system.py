from progpy import PrognosticsModel
import numpy as np

class MilkSystem(PrognosticsModel):
    """
    Prognostics model for a milk system that heats, froths, and dispenses milk for coffee beverages with quality and hygiene monitoring.
    
    Events:
        lactose_cross_contamination: Cannot guarantee lactose-free milk on tank #2 when using dual milk types
    
    Inputs:
        steam_flow: Steam pressure for milk heating and frothing (bar)
        milk_quantity: Duration of milk dispensing operation (seconds)
        stop_temperature: Target temperature to stop heating (c)
        foam_texture: Desired foam texture setting (0-100) (dimensionless)
        milk_delay_time: Delay before milk dispensing starts (seconds)
        milk_temperature_setting: Target milk temperature setting (c)
    
    States:
        milk_quality: Milk quality degrading with temperature exposure and time (percent)
        hygiene_level: Milk system hygiene degrading with contamination buildup (percent)
        actual_temperature: Actual milk temperature following target temperature (c)
    
    Outputs:
        frothed_milk: Flow rate of processed frothed milk (ml/s)
    """
    
    inputs = [
        'steam_flow',
        'milk_quantity', 
        'stop_temperature',
        'foam_texture',
        'milk_delay_time',
        'milk_temperature_setting'
    ]
    
    states = [
        'milk_quality',
        'hygiene_level',
        'actual_temperature'
    ]
    
    outputs = ['frothed_milk', 'foam_texture']
    
    events = [
        'lactose_cross_contamination'
    ]
    
    units = {
        'steam_flow': 'bar',
        'milk_quantity': 'seconds',
        'stop_temperature': 'c',
        'foam_texture': '',
        'milk_delay_time': 'seconds',
        'milk_temperature_setting': 'c',
        'milk_quality': 'percent',
        'hygiene_level': 'percent',
        'actual_temperature': 'c',
        'frothed_milk': 'ml/s'
    }
    
    default_parameters = {
        'milk_quality_degradation_time': 3600.0,
        'hygiene_degradation_time': 7200.0,
        'temperature_stress_factor': 1.0,
        'contamination_rate_factor': 1.0,
        'base_flow_rate': 15.0,
        'temperature_tracking_coeff': 0.3,
        'foam_efficiency_factor': 0.01,
        'hygiene_threshold': 0.7,
        'x0': {
            'milk_quality': 1.0,
            'hygiene_level': 1.0,
            'actual_temperature': 20.0
        }
    }
    
    def initialize(self, u=None, z=None):
        x = self.StateContainer({
            'milk_quality': self.parameters['x0']['milk_quality'],
            'hygiene_level': self.parameters['x0']['hygiene_level'],
            'actual_temperature': self.parameters['x0']['actual_temperature']
        })
        
        if u is not None and u.get('milk_temperature_setting') is not None:
            x['actual_temperature'] = u['milk_temperature_setting']
        
        return x
    
    def next_state(self, x, u, dt):
        # Degradation rate for milk_quality
        milk_quality_rate = 1.0 / self.parameters['milk_quality_degradation_time']
        temperature_stress = max(1.0, u['stop_temperature'] / 65.0) if u['stop_temperature'] is not None else 1.0
        milk_quality_degradation = milk_quality_rate * self.parameters['temperature_stress_factor'] * temperature_stress * dt
        new_milk_quality = x['milk_quality'] - milk_quality_degradation
        new_milk_quality = max(0.0, min(1.0, new_milk_quality))
        
        # Degradation rate for hygiene_level
        hygiene_rate = 1.0 / self.parameters['hygiene_degradation_time']
        hygiene_degradation = hygiene_rate * self.parameters['contamination_rate_factor'] * dt
        new_hygiene_level = x['hygiene_level'] - hygiene_degradation
        new_hygiene_level = max(0.0, min(1.0, new_hygiene_level))
        
        # Temperature tracking
        target_temp = u['milk_temperature_setting'] if u['milk_temperature_setting'] is not None else x['actual_temperature']
        coefficient = min(self.parameters['temperature_tracking_coeff'], 0.5)
        temp_change = coefficient * (target_temp - x['actual_temperature']) * dt
        new_actual_temperature = x['actual_temperature'] + temp_change
        new_actual_temperature = max(0.0, min(100.0, new_actual_temperature))
        
        return self.StateContainer({
            'milk_quality': new_milk_quality,
            'hygiene_level': new_hygiene_level,
            'actual_temperature': new_actual_temperature
        })
    
    def output(self, x):
        # Get inputs from current context or use defaults
        steam_flow = getattr(self, '_current_u', {}).get('steam_flow', 1.0)
        milk_quantity = getattr(self, '_current_u', {}).get('milk_quantity', 100.0)
        foam_texture = getattr(self, '_current_u', {}).get('foam_texture', 50.0)
        
        steam_efficiency = min(1.0, steam_flow / 0.8) if steam_flow is not None else 1.0
        quantity_factor = (milk_quantity / 100.0) if milk_quantity is not None else 1.0
        foam_factor = (1.0 + foam_texture * self.parameters['foam_efficiency_factor']) if foam_texture is not None else 1.0
        
        frothed_milk = (self.parameters['base_flow_rate'] * 
                       x['milk_quality'] * 
                       x['hygiene_level'] * 
                       quantity_factor * 
                       foam_factor * 
                       steam_efficiency)
        
        foam_texture = 65.0 * x['milk_quality'] * x['hygiene_level']
        return self.OutputContainer({
            'frothed_milk': frothed_milk,
            'foam_texture': foam_texture,
        })
    
    def event_state(self, x):
        return {
            'lactose_cross_contamination': max(0.0, min(1.0, x['hygiene_level'] / self.parameters['hygiene_threshold']))
        }
    
    def threshold_met(self, x):
        return {
            'lactose_cross_contamination': bool(x['hygiene_level'] < self.parameters['hygiene_threshold'])
        }