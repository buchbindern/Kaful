import numpy as np
from progpy import PrognosticsModel

class CoffeeBoiler(PrognosticsModel):
    """
    Prognostics model for a coffee boiler.

    Limescale accumulates with each brew (water volume through the boiler).
    Realistic timescale: descaling needed every ~3 months on heavy commercial
    (~18,000-20,000 brews). At dt=1 per brew that is ~18,000 steps.

    Temperature stability degrades nonlinearly as limescale builds —
    barely noticeable early, significant impact after 60%+ buildup.
    """

    inputs  = ['water_supply', 'water_quantity']
    states  = ['limescale_buildup', 'temperature_stability']
    outputs = ['brewing_water', 'water_temperature']
    events  = ['coffee_boiler_heating_warning',
               'coffee_boiler_temp_sensor_failure',
               'coffee_boiler_heating_stop']

    default_parameters = {
        # Limescale: 0-100 scale. Reaches ~100 at ~18,000 brews.
        # rate = 100 / 18000 ≈ 0.0056 per brew
        'limescale_accumulation_rate': 0.0055,

        # Temperature stability: 100 = perfect, 0 = failed.
        # Nonlinear — barely degrades until limescale > 50%,
        # then accelerates. Full degradation at ~20,000 brews.
        'stability_degradation_rate':  0.00529,  # base rate per brew
        'stability_acceleration':      3.0,        # exponent on limescale fraction

        'base_brewing_temperature':    93.0,
        'temperature_loss_factor':     0.05,       # max temp loss at 100% scale = 5°C

        # Event thresholds on temperature_stability
        'heating_warning_threshold':   80.0,
        'sensor_failure_threshold':    60.0,
        'heating_stop_threshold':      40.0,

        'x0': {
            'limescale_buildup':    0.0,
            'temperature_stability': 100.0,
        }
    }

    def initialize(self, u=None, z=None):
        return self.StateContainer({
            'limescale_buildup':    self.parameters['x0']['limescale_buildup'],
            'temperature_stability': self.parameters['x0']['temperature_stability'],
        })

    def next_state(self, x, u, dt):
        p = self.parameters

        # Limescale accumulates linearly with each brew (water volume)
        new_limescale = x['limescale_buildup'] + p['limescale_accumulation_rate'] * dt
        new_limescale = max(0.0, min(100.0, new_limescale))

        # Temperature stability degrades nonlinearly driven by limescale
        # Low limescale (<50%) → almost no effect
        # High limescale (>70%) → rapidly accelerating degradation
        scale_fraction = new_limescale / 100.0
        stability_loss = (p['stability_degradation_rate'] *
                          (scale_fraction ** p['stability_acceleration']) * dt)
        new_stability = x['temperature_stability'] - stability_loss
        new_stability = max(0.0, min(100.0, new_stability))

        return self.StateContainer({
            'limescale_buildup':    new_limescale,
            'temperature_stability': new_stability,
        })

    def output(self, x):
        p = self.parameters
        # Brewing temp drops slightly with limescale (insulation effect)
        temp_loss = p['temperature_loss_factor'] * x['limescale_buildup']
        brewing_temp = p['base_brewing_temperature'] - temp_loss
        return self.OutputContainer({
            'brewing_water':    brewing_temp,
            'water_temperature': brewing_temp,
        })

    def event_state(self, x):
        p = self.parameters
        s = x['temperature_stability']
        hw  = p['heating_warning_threshold']
        sf  = p['sensor_failure_threshold']
        hs  = p['heating_stop_threshold']
        return {
            'coffee_boiler_heating_warning':     max(0.0, min(1.0, (s - hw) / (100.0 - hw))),
            'coffee_boiler_temp_sensor_failure': max(0.0, min(1.0, (s - sf) / (100.0 - sf))),
            'coffee_boiler_heating_stop':        max(0.0, min(1.0, (s - hs) / (100.0 - hs))),
        }

    def threshold_met(self, x):
        p = self.parameters
        s = x['temperature_stability']
        return {
            'coffee_boiler_heating_warning':     bool(s < p['heating_warning_threshold']),
            'coffee_boiler_temp_sensor_failure': bool(s < p['sensor_failure_threshold']),
            'coffee_boiler_heating_stop':        bool(s < p['heating_stop_threshold']),
        }