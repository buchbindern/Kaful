from progpy import PrognosticsModel
import numpy as np

class BrewingChamber(PrognosticsModel):
    """
    Prognostics model for a brewing chamber that controls coffee extraction process 
    through tamping, pre-infusion, and brewing with precise pressure and timing control.
    
    Events: (1)
        bean_hopper_empty_locked: Insufficient coffee distribution quality indicating empty hopper or mechanical lock
    
    Inputs: (9)
        ground_coffee: Mass of ground coffee loaded into chamber (g)
        brewing_water: Temperature of water for brewing (°C)
        cake_thickness: Target thickness of coffee cake after tamping (mm)
        tamping_pressure: Applied tamping pressure (kg)
        pre_infusion_time: Duration of pre-infusion phase (seconds)
        relax_time: Relaxation time between tamping and extraction (seconds)
        second_tamping: Additional tamping depth adjustment (mm)
        coffee_cycles: Number of brewing cycles performed
        bypass_quantity: Percentage of water bypassing coffee cake
    
    States: (2)
        powder_distribution_quality: Quality of coffee powder distribution in chamber (percent)
        tamping_consistency: Consistency of electronic tamping mechanism (percent)
    
    Outputs: (2)
        brewed_coffee: Flow rate of extracted coffee (ml/s)
        extraction_time: Total time for coffee extraction (seconds)
    """
    
    inputs = [
        'ground_coffee',
        'brewing_water', 
        'cake_thickness',
        'tamping_pressure',
        'pre_infusion_time',
        'relax_time',
        'second_tamping',
        'coffee_cycles',
        'bypass_quantity'
    ]
    
    states = [
        'powder_distribution_quality',
        'tamping_consistency'
    ]
    
    outputs = ['brewed_coffee', 'extraction_time', 'tamping_pressure', 'cake_thickness']
    
    events = [
        'bean_hopper_empty_locked'
    ]
    
    units = {
        'ground_coffee': 'g',
        'brewing_water': '°C',
        'cake_thickness': 'mm',
        'tamping_pressure': 'kg',
        'pre_infusion_time': 'seconds',
        'relax_time': 'seconds',
        'second_tamping': 'mm',
        'coffee_cycles': '',
        'bypass_quantity': '',
        'powder_distribution_quality': 'percent',
        'tamping_consistency': 'percent',
        'brewed_coffee': 'ml/s',
        'extraction_time': 'seconds'
    }
    
    default_parameters = {
        'distribution_degradation_cycles': 10000.0,
        'tamping_degradation_cycles': 15000.0,
        'base_flow_rate': 2.5,
        'base_extraction_time': 22.0,
        'nominal_tamping_pressure': 20.0,
        'nominal_cake_thickness': 14.0,
        'flow_degradation_factor': 0.8,
        'time_degradation_factor': 1.3,
        'hopper_empty_threshold': 0.1,
        'x0': {
            'powder_distribution_quality': 1.0,
            'tamping_consistency': 1.0
        }
    }
    
    def initialize(self, u=None, z=None):
        x = self.StateContainer({
            'powder_distribution_quality': 1.0,
            'tamping_consistency': 1.0
        })
        
        if u is not None and 'ground_coffee' in u and u['ground_coffee'] is not None:
            pass
        
        if z is not None and 'brewed_coffee' in z and z['brewed_coffee'] is not None:
            pass
            
        return x
    
    def next_state(self, x, u, dt):
        params = self.parameters
        
        # Calculate degradation rates from timescales
        distribution_rate = 1.0 / params['distribution_degradation_cycles']
        tamping_rate = 1.0 / params['tamping_degradation_cycles']
        
        # Get coffee cycles input, default to 0 if None
        coffee_cycles = u['coffee_cycles'] if u['coffee_cycles'] is not None else 0.0
        
        # Update powder distribution quality (degradation state)
        powder_degradation = distribution_rate * coffee_cycles * dt
        new_powder_quality = x['powder_distribution_quality'] - powder_degradation
        new_powder_quality = max(0.0, min(1.0, new_powder_quality))
        
        # Update tamping consistency (degradation state)
        tamping_degradation = tamping_rate * coffee_cycles * dt
        new_tamping_consistency = x['tamping_consistency'] - tamping_degradation
        new_tamping_consistency = max(0.0, min(1.0, new_tamping_consistency))
        
        return self.StateContainer({
            'powder_distribution_quality': new_powder_quality,
            'tamping_consistency': new_tamping_consistency
        })
    
    def output(self, x):
        params = self.parameters
        
        # Calculate brewed coffee flow rate
        base_flow = params['base_flow_rate']
        powder_quality = x['powder_distribution_quality']
        tamping_quality = x['tamping_consistency']
        
        # Check if system is degraded (either quality below 1.0)
        is_degraded = powder_quality < 1.0 or tamping_quality < 1.0
        
        if is_degraded:
            flow_rate = base_flow * powder_quality * tamping_quality * params['flow_degradation_factor']
        else:
            flow_rate = base_flow
            
        # Scale by ground coffee amount (assuming 24g is nominal)
        # Note: ground_coffee is not available in output method, so using nominal scaling
        flow_rate = flow_rate * (24.0 / 24.0)  # Placeholder for ground_coffee scaling
        
        # Calculate extraction time
        base_time = params['base_extraction_time']
        time_factor = params['time_degradation_factor']
        
        extraction_time = base_time * (1 + (1 - powder_quality) * time_factor) * (1 + (1 - tamping_quality) * time_factor)
        
        return self.OutputContainer({
            'brewed_coffee':    flow_rate,
            'extraction_time':  extraction_time,
            'tamping_pressure': self.parameters['nominal_tamping_pressure'] * tamping_quality,
            'cake_thickness':   self.parameters['nominal_cake_thickness'] * powder_quality,
        })
    
    def event_state(self, x):
        params = self.parameters
        
        # Event state for bean_hopper_empty_locked
        # Based on powder_distribution_quality threshold
        powder_quality = x['powder_distribution_quality']
        threshold = params['hopper_empty_threshold']
        
        # Event state: 1.0 = healthy, 0.0 = event occurred
        # When powder_quality drops below threshold, event occurs
        if powder_quality >= threshold:
            event_state_val = (powder_quality - threshold) / (1.0 - threshold)
        else:
            event_state_val = 0.0
            
        event_state_val = max(0.0, min(1.0, event_state_val))
        
        return {
            'bean_hopper_empty_locked': event_state_val
        }
    
    def threshold_met(self, x):
        params = self.parameters
        
        # Threshold met when powder distribution quality falls below threshold
        hopper_empty = bool(x['powder_distribution_quality'] < params['hopper_empty_threshold'])
        
        return {
            'bean_hopper_empty_locked': hopper_empty
        }