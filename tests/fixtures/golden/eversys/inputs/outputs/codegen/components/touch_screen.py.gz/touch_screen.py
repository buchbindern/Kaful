from progpy import PrognosticsModel
import numpy as np

class TouchScreen(PrognosticsModel):
    """
    Prognostics model for a touch screen interface component.
    
    Primary user interface for coffee machine product selection and dispensing control.
    Touch screen degradation is primarily driven by surface contamination from user interactions.
    """
    
    inputs = []
    
    outputs = [
        'product_button_pressed',
        'dispensing_start_time', 
        'dispensing_stop_time',
        'manual_stop_pressed',
        'product_key_name',
        'product_type',
        'double_product',
        'manual_stop_triggered',
        'dispensing_end_time'
    ]
    
    states = [
        'surface_cleanliness'
    ]
    
    events = [
        'action_required_indicator'
    ]
    
    units = {
        'product_button_pressed': None,
        'dispensing_start_time': None,
        'dispensing_stop_time': None,
        'manual_stop_pressed': None,
        'product_key_name': 'text',
        'product_type': 'text',
        'double_product': 'boolean',
        'manual_stop_triggered': 'boolean',
        'dispensing_end_time': None,
        'surface_cleanliness': 'percent'
    }
    
    default_parameters = {
        'surface_degradation_timescale': 100000,
        'usage_intensity': 1.0,
        'action_required_threshold': 0.3,
        'x0': {
            'surface_cleanliness': 1.0
        }
    }
    
    def initialize(self, u=None, z=None):
        x = self.StateContainer({
            'surface_cleanliness': 1.0
        })
        return x
    
    def next_state(self, x, u, dt):
        # Calculate degradation rate from timescale
        rate = 1.0 / self.parameters['surface_degradation_timescale']
        
        # Apply degradation logic
        degradation = rate * self.parameters['usage_intensity'] * dt
        new_surface_cleanliness = x['surface_cleanliness'] - degradation
        
        # Clamp to valid range
        new_surface_cleanliness = max(0.0, min(1.0, new_surface_cleanliness))
        
        return self.StateContainer({
            'surface_cleanliness': new_surface_cleanliness
        })
    
    def output(self, x):
        # Touch screen outputs are generated based on user interactions
        # Output reliability and accuracy decrease as surface_cleanliness degrades
        # When surface_cleanliness is below action_required_threshold, interface responsiveness may be compromised
        
        return self.OutputContainer({
            'product_button_pressed': None,
            'dispensing_start_time': None,
            'dispensing_stop_time': None,
            'manual_stop_pressed': None,
            'product_key_name': None,
            'product_type': None,
            'double_product': False,
            'manual_stop_triggered': False,
            'dispensing_end_time': None
        })
    
    def event_state(self, x):
        # action_required_indicator triggers when surface_cleanliness falls below action_required_threshold
        surface_cleanliness_event_state = max(0.0, min(1.0, 
            (x['surface_cleanliness'] - 0.0) / (self.parameters['action_required_threshold'] - 0.0)
        ))
        
        return {
            'action_required_indicator': surface_cleanliness_event_state
        }
    
    def threshold_met(self, x):
        return {
            'action_required_indicator': bool(x['surface_cleanliness'] < self.parameters['action_required_threshold'])
        }