from progpy import PrognosticsModel
import numpy as np

class PowderUnit(PrognosticsModel):
    """
    Prognostics model for a powder unit that mixes and dispenses powder additives 
    with controlled accuracy, subject to buildup and dispensing degradation.
    
    Events: (2)
        mixer_blockage: Mixer blocked or damaged by foreign objects
        incompatible_grinder_configuration: Powder unit incompatible with 4 grinders option
    
    Inputs: (1)
        powder_density: Density of powder being processed (g100ml)
    
    States: (2)
        mixer_buildup: Powder residue buildup in mixer components (percent)
        dispensing_accuracy: Dispensing accuracy degrading with contamination (percent)
    
    Outputs: (0)
    """
    
    inputs = ['powder_density']
    states = ['mixer_buildup', 'dispensing_accuracy']
    outputs = []
    events = ['mixer_blockage', 'incompatible_grinder_configuration']
    
    units = {
        'powder_density': 'g100ml',
        'mixer_buildup': 'percent',
        'dispensing_accuracy': 'percent'
    }
    
    default_parameters = {
        'buildup_rate': 0.1,
        'dispensing_degradation_time': 500000.0,
        'mixer_blockage_threshold': 85.0,
        'accuracy_warning_threshold': 75.0,
        'x0': {
            'mixer_buildup': 0.0,
            'dispensing_accuracy': 100.0
        }
    }
    
    def initialize(self, u=None, z=None):
        x = self.StateContainer({
            'mixer_buildup': 0.0,
            'dispensing_accuracy': 100.0
        })
        
        if u is not None and 'powder_density' in u and u['powder_density'] is not None:
            pass
        
        if z is not None:
            pass
            
        return x
    
    def next_state(self, x, u, dt):
        # ACCUMULATION state: mixer_buildup
        buildup_increase = self.parameters['buildup_rate'] * u['powder_density'] * dt
        new_mixer_buildup = x['mixer_buildup'] + buildup_increase
        new_mixer_buildup = max(0.0, min(100.0, new_mixer_buildup))
        
        # DEGRADATION state: dispensing_accuracy
        degradation_rate = 1.0 / self.parameters['dispensing_degradation_time']
        degradation_amount = degradation_rate * u['powder_density'] * dt
        new_dispensing_accuracy = x['dispensing_accuracy'] - degradation_amount
        new_dispensing_accuracy = max(0.0, min(100.0, new_dispensing_accuracy))
        
        return self.StateContainer({
            'mixer_buildup': new_mixer_buildup,
            'dispensing_accuracy': new_dispensing_accuracy
        })
    
    def output(self, x):
        return self.OutputContainer({})
    
    def event_state(self, x):
        mixer_blockage_es = max(0.0, min(1.0, 
            (self.parameters['mixer_blockage_threshold'] - x['mixer_buildup']) / 
            self.parameters['mixer_blockage_threshold']))
        
        accuracy_warning_es = max(0.0, min(1.0,
            (x['dispensing_accuracy'] - self.parameters['accuracy_warning_threshold']) /
            (100.0 - self.parameters['accuracy_warning_threshold'])))
        
        return {
            'mixer_blockage': mixer_blockage_es,
            'incompatible_grinder_configuration': accuracy_warning_es
        }
    
    def threshold_met(self, x):
        return {
            'mixer_blockage': bool(x['mixer_buildup'] >= self.parameters['mixer_blockage_threshold']),
            'incompatible_grinder_configuration': bool(x['dispensing_accuracy'] <= self.parameters['accuracy_warning_threshold'])
        }