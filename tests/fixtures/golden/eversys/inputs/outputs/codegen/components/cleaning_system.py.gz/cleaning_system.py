from progpy import PrognosticsModel
import numpy as np


class CleaningSystem(PrognosticsModel):
    """
    Prognostics model for a cleaning system that maintains system cleanliness and hygiene safety 
    through automated cleaning cycles, preventing contamination and ensuring food safety compliance.
    
    Events: (1)
        cleaning_required_lockout: Machine prevents drink preparation when cleaning is required
    
    Inputs: (0)
        None
    
    States: (2)
        system_cleanliness: Overall system cleanliness degrading without regular cleaning (percent)
        hygiene_safety: Food hygiene safety level degrading with improper cleaning (percent)
    
    Outputs: (0)
        None
    """
    
    inputs = []
    outputs = []
    states = ['system_cleanliness', 'hygiene_safety']
    events = ['cleaning_required_lockout']
    
    units = {
        'system_cleanliness': 'percent',
        'hygiene_safety': 'percent'
    }
    
    default_parameters = {
        'cleanliness_degradation_time': 86400.0,  # s
        'cleanliness_degradation_rate': 1.0,      # dimensionless
        'hygiene_degradation_time': 43200.0,      # s
        'hygiene_degradation_rate': 1.0,          # dimensionless
        'cleaning_lockout_threshold': 20.0,       # percent
        'hygiene_lockout_threshold': 30.0,        # percent
        'x0': {
            'system_cleanliness': 100.0,
            'hygiene_safety': 100.0
        }
    }
    
    def initialize(self, u=None, z=None):
        """Initialize the cleaning system state"""
        x = self.StateContainer({
            'system_cleanliness': 100.0,
            'hygiene_safety': 100.0
        })
        return x
    
    def next_state(self, x, u, dt):
        """Update the cleaning system state"""
        # Calculate degradation rates from timescales
        cleanliness_rate = self.parameters['cleanliness_degradation_rate'] / self.parameters['cleanliness_degradation_time']
        hygiene_rate = self.parameters['hygiene_degradation_rate'] / self.parameters['hygiene_degradation_time']
        
        # Update system cleanliness (degradation state)
        new_cleanliness = x['system_cleanliness'] - cleanliness_rate * dt
        new_cleanliness = max(0.0, min(100.0, new_cleanliness))
        
        # Update hygiene safety (degradation state)
        new_hygiene = x['hygiene_safety'] - hygiene_rate * dt
        new_hygiene = max(0.0, min(100.0, new_hygiene))
        
        return self.StateContainer({
            'system_cleanliness': new_cleanliness,
            'hygiene_safety': new_hygiene
        })
    
    def output(self, x):
        """Calculate outputs (none for this component)"""
        return self.OutputContainer({})
    
    def event_state(self, x):
        """Calculate event states"""
        # cleaning_required_lockout event state based on minimum of cleanliness thresholds
        cleanliness_health = max(0.0, min(1.0, x['system_cleanliness'] / self.parameters['cleaning_lockout_threshold']))
        hygiene_health = max(0.0, min(1.0, x['hygiene_safety'] / self.parameters['hygiene_lockout_threshold']))
        
        # Event occurs when either threshold is exceeded, so use minimum
        lockout_health = min(cleanliness_health, hygiene_health)
        
        return {
            'cleaning_required_lockout': lockout_health
        }
    
    def threshold_met(self, x):
        """Check if thresholds are met"""
        cleaning_lockout = bool(x['system_cleanliness'] < self.parameters['cleaning_lockout_threshold'] or 
                               x['hygiene_safety'] < self.parameters['hygiene_lockout_threshold'])
        
        return {
            'cleaning_required_lockout': cleaning_lockout
        }