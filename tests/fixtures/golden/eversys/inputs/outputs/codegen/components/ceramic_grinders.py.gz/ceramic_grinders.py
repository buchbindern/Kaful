from progpy import PrognosticsModel
import numpy as np

class CeramicGrinders(PrognosticsModel):
    """
    Prognostics model for ceramic coffee grinders.

    Burr wear is modeled as a 0-100% health index (100=new, 0=worn out).
    Degradation is nonlinear: accelerates as wear increases (worn burrs
    create more friction, which accelerates further wear).

    Realistic timescale: ~500,000 brews to replacement on heavy commercial.
    At dt=1 per brew, that is ~500,000 steps.
    """

    inputs  = ['bean_flow']
    outputs = ['ground_coffee', 'grind_consistency']
    states  = ['burr_health', 'grind_consistency']
    events  = ['burr_replacement_needed', 'grinder_blocked']

    default_parameters = {
        # Base wear rate per brew: 1/500000 = 0.000002 health points per brew
        # Nonlinear factor: wear accelerates as health drops
        'base_wear_rate':           0.0000463,   # health fraction lost per unit bean_flow per dt
        'wear_acceleration_factor': 2.0,         # exponent — worn burrs wear faster
        'grind_degradation_rate':   0.000001,    # grind_consistency loss per brew at full wear
        'nominal_bean_flow':        1.0,         # reference bean_flow for rate normalisation

        # Event thresholds (health fraction 0-1)
        'replacement_threshold':    0.15,        # burr_health below this → replace
        'blockage_threshold':       0.10,        # grind_consistency below this → blocked

        'grinding_efficiency':      0.95,

        'x0': {
            'burr_health':       1.0,    # 100% new
            'grind_consistency': 1.0,    # 100% consistent
        }
    }

    def initialize(self, u=None, z=None):
        return self.StateContainer({
            'burr_health':       self.parameters['x0']['burr_health'],
            'grind_consistency': self.parameters['x0']['grind_consistency'],
        })

    def next_state(self, x, u, dt):
        p = self.parameters
        bean_flow = max(0.0, u['bean_flow']) if u['bean_flow'] is not None else p['nominal_bean_flow']

        # Nonlinear wear: accelerates as health drops
        # When burr_health=1.0 (new): wear = base_rate * bean_flow
        # When burr_health=0.5 (half worn): wear is higher due to acceleration
        wear_multiplier = 1.0 + p['wear_acceleration_factor'] * (1.0 - x['burr_health'])
        wear = p['base_wear_rate'] * bean_flow * wear_multiplier * dt
        new_burr_health = max(0.0, x['burr_health'] - wear)

        # Grind consistency degrades proportionally to burr wear
        # Barely changes when healthy; degrades faster in last 20% of life
        # Clamp at 0: ensemble members can start slightly above 1.0, and a negative base ** 1.5 is NaN
        consistency_loss = p['grind_degradation_rate'] * max(0.0, 1.0 - new_burr_health) ** 1.5 * dt
        new_grind_consistency = max(0.0, x['grind_consistency'] - consistency_loss)

        return self.StateContainer({
            'burr_health':       new_burr_health,
            'grind_consistency': new_grind_consistency,
        })

    def output(self, x):
        ground_coffee = self.parameters['grinding_efficiency'] * x['grind_consistency']
        return self.OutputContainer({
            'ground_coffee':    ground_coffee,
            'grind_consistency': x['grind_consistency'] * 100.0,  # output as percent
        })

    def event_state(self, x):
        p = self.parameters
        # 1.0 = healthy, 0.0 = event has occurred
        burr_es = max(0.0, min(1.0,
            (x['burr_health'] - p['replacement_threshold']) /
            (1.0 - p['replacement_threshold'])
        ))
        blockage_es = max(0.0, min(1.0,
            (x['grind_consistency'] - p['blockage_threshold']) /
            (1.0 - p['blockage_threshold'])
        ))
        return {
            'burr_replacement_needed': burr_es,
            'grinder_blocked':         blockage_es,
        }

    def threshold_met(self, x):
        p = self.parameters
        return {
            'burr_replacement_needed': bool(x['burr_health'] < p['replacement_threshold']),
            'grinder_blocked':         bool(x['grind_consistency'] < p['blockage_threshold']),
        }