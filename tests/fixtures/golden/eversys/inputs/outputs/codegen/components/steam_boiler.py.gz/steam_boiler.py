from progpy import PrognosticsModel
import numpy as np

class SteamBoiler(PrognosticsModel):
    """
    Steam Boiler Component Model.

    Same limescale physics as coffee boiler — same water source, same
    mineral accumulation rate. Pressure stability degrades nonlinearly
    as scale restricts flow paths and insulates heating elements.

    Realistic timescale: descaling every ~18,000 brews (heavy commercial).
    """

    inputs  = ['water_supply', 'water_temperature', 'hot_water_duration']
    states  = ['limescale_buildup', 'pressure_stability']
    outputs = ['steam_flow', 'stop_temperature']
    events  = ['steam_boiler_heating', 'steam_boiler_emptied',
               'empty_steam_boiler', 'fill_steam_boiler',
               'steam_pressure_too_low']

    default_parameters = {
        # Same accumulation rate as coffee boiler — same water supply
        'limescale_accumulation_rate': 0.0055,

        # Pressure stability degrades nonlinearly with limescale
        # Scale restricts steam flow paths — critical after ~70% buildup
        'stability_degradation_rate':  0.00529,
        'stability_acceleration':      2.5,

        'base_steam_pressure':         0.8,
        'water_supply_factor':         0.32,
        'temperature_efficiency_factor': 0.01,
        'nominal_stop_temperature':    65.0,

        # Event thresholds on pressure_stability (%)
        'heating_threshold':     80.0,
        'emptied_threshold':     20.0,
        'empty_threshold':       10.0,
        'fill_threshold':        70.0,   # limescale threshold for fill event
        'low_pressure_threshold': 60.0,

        'x0': {
            'limescale_buildup':  0.0,
            'pressure_stability': 100.0,
        }
    }

    def initialize(self, u=None, z=None):
        return self.StateContainer({
            'limescale_buildup':  self.parameters['x0']['limescale_buildup'],
            'pressure_stability': self.parameters['x0']['pressure_stability'],
        })

    def next_state(self, x, u, dt):
        p = self.parameters

        # Limescale accumulates linearly per brew
        new_limescale = x['limescale_buildup'] + p['limescale_accumulation_rate'] * dt
        new_limescale = max(0.0, min(100.0, new_limescale))

        # Pressure stability degrades nonlinearly driven by limescale
        scale_fraction = new_limescale / 100.0
        stability_loss = (p['stability_degradation_rate'] *
                          (scale_fraction ** p['stability_acceleration']) * dt)
        new_pressure_stability = x['pressure_stability'] - stability_loss
        new_pressure_stability = max(0.0, min(100.0, new_pressure_stability))

        return self.StateContainer({
            'limescale_buildup':  new_limescale,
            'pressure_stability': new_pressure_stability,
        })

    def output(self, x):
        p = self.parameters
        steam_flow = (p['base_steam_pressure'] *
                      p['water_supply_factor'] *
                      (x['pressure_stability'] / 100.0) *
                      (1.0 - x['limescale_buildup'] / 200.0))
        stop_temp = p['nominal_stop_temperature'] * (x['pressure_stability'] / 100.0)
        return self.OutputContainer({
            'steam_flow':       steam_flow,
            'stop_temperature': stop_temp,
        })

    def event_state(self, x):
        p  = self.parameters
        ps = x['pressure_stability']
        ls = x['limescale_buildup']
        return {
            'steam_boiler_heating':    max(0.0, min(1.0, (ps - p['heating_threshold']) / (100.0 - p['heating_threshold']))),
            'steam_boiler_emptied':    max(0.0, min(1.0, (ps - p['emptied_threshold']) / (100.0 - p['emptied_threshold']))),
            'empty_steam_boiler':      max(0.0, min(1.0, (ps - p['empty_threshold'])   / (100.0 - p['empty_threshold']))),
            'fill_steam_boiler':       max(0.0, min(1.0, (p['fill_threshold'] - ls)    / p['fill_threshold'])),
            'steam_pressure_too_low':  max(0.0, min(1.0, (ps - p['low_pressure_threshold']) / (100.0 - p['low_pressure_threshold']))),
        }

    def threshold_met(self, x):
        p  = self.parameters
        ps = x['pressure_stability']
        ls = x['limescale_buildup']
        return {
            'steam_boiler_heating':   bool(ps < p['heating_threshold']),
            'steam_boiler_emptied':   bool(ps < p['emptied_threshold']),
            'empty_steam_boiler':     bool(ps < p['empty_threshold']),
            'fill_steam_boiler':      bool(ls > p['fill_threshold']),
            'steam_pressure_too_low': bool(ps < p['low_pressure_threshold']),
        }